class TodoList < ActiveRecord::Base
end
